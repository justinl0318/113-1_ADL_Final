### [CosyVoice](https://github.com/FunAudioLLM/CosyVoice)

- 功能：生成資料集。
- Repo 中額外寫的程式
    - ```text_gen.py```：使用 GPT api 和事先整理的辭典生成對話資料。
    - ```audio_gen.py```：用對話文字資料生成其語音資料。
    - ```transcription_gen.py```：生成語音資料辨識結果。
    - ```concat_gen.py```：把辭典的每列文字串起來生成語音。
- 注意事項
    - 要下載 Text-to-Speech Model 在  ```pretrained_models``` 目錄。
    - 建環境跑程式時很常遇到 ```FAQ.md``` 裡的問題。

### [fish-speech-1.4.3](https://github.com/fishaudio/fish-speech/releases/tag/v1.4.3)

- 功能：要做 evaluation 的 Audio LM。
- 注意事項
    - 要下載 Fish Agent 的 Models 在  ```checkpoints``` 目錄。
    - 目前 Repo 最新版不能跑，只能用 1.4 版本。