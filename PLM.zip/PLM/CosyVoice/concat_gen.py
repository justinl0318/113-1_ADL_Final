# import os
# import nvidia.cublas.lib
# import nvidia.cudnn.lib

# print(os.path.dirname(nvidia.cublas.lib.__file__) + ":" + os.path.dirname(nvidia.cudnn.lib.__file__))

from cosyvoice.cli.cosyvoice import CosyVoice
from cosyvoice.utils.file_utils import load_wav
import torchaudio
import pandas as pd
import json

# load TTS
# zero_shot usage, <|zh|><|en|><|jp|><|yue|><|ko|> for Chinese/English/Japanese/Cantonese/Korean
cosyvoice = CosyVoice('pretrained_models/CosyVoice-300M') # or change to pretrained_models/CosyVoice-300M for 50Hz inference
prompt_speech_16k = load_wav('zero_shot_prompt.wav', 16000)

# FUNC
def gen_audio(text, path):
    for i, j in enumerate(cosyvoice.inference_zero_shot(text, '希望你以后能够做的比我还好呦。', prompt_speech_16k, stream=False)):
        torchaudio.save(path, j['tts_speech'], 22050)

def convert_digits_to_chinese(input_str):
    chinese_digits = ["零", "一", "二", "三", "四", "五", "六", "七", "八", "九"]
    
    # 將字串中的數字轉成中文數字
    result_str = "".join(chinese_digits[int(char)] if char.isdigit() else char for char in input_str)
    return result_str

# Load the CSV file
csv_file = '活網用語辭典.csv'
df = pd.read_csv(csv_file)

results = []
for i, row in df.iterrows():
    print(i)
    word = convert_digits_to_chinese(row['詞彙'])
    definition = convert_digits_to_chinese(row['釋義'])
    example = convert_digits_to_chinese(row['例句'])

    concat_text = word + definition + example
    concat_audio_path = f"concat_audio/{i}.wav"
    gen_audio(concat_text, concat_audio_path)

    results.append(
        {
            "concat_text": concat_text,
            "concat_audio_path": concat_audio_path
        }
    )

    # Save to a JSON file
    output_file = 'concat_data.json'
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

print(f"JSON output saved to {output_file}")
