import pandas as pd
import json
from openai import OpenAI

# Load the CSV file
csv_file = '活網用語辭典.csv'
df = pd.read_csv(csv_file)

# Initialize OpenAI client
openai_client = OpenAI(api_key="")

# Prompt
prompt1 = """請針對以下詞彙、釋義和例句生成5筆A和B的對話。
### 規則
- 對話要有台灣網民的語氣，且彼此不能使用相同的情境。
- 第1第2筆對話中，只有A能使用辭彙
- 第3第4筆對話中，只有B能使用辭彙
- 第5筆對話中，A和B其中一人要使用辭彙
### 詞彙：{word}
### 釋義：{definition}
### 例句：{example}
"""
prompt2 = """### 輸出格式：
{
  "word": {詞彙},
  "definition": {釋義},
  "dialogues":  [
    {
      "A": {第一問}, 
      "B": {第一答}
    },
    {
      "A": {第二問}, 
      "B": {第二答}
    },
    {
      "A": {第三問}, 
      "B": {第三答}
    },
    {
      "A": {第四問}, 
      "B": {第四答}
    },
    {
      "A": {第五問}, 
      "B": {第五答}
    }
  ]
}"""

# Function to call GPT-4o model
def generate_dialogue(word, definition, example):
    messages = [
        {
            "role": "system", 
            "content": prompt1.format(word=word, definition=definition, example=example) + prompt2
        }
    ]
    response = openai_client.chat.completions.create(
        model="gpt-4o-mini",
        messages=messages,
        temperature=0.0001
    )
    response = response.choices[0].message.content
    # print(response)
    return json.loads(response)

# Generate outputs
results = []
for i, row in df.iterrows():
    print(i)
    word = row['詞彙']
    definition = row['釋義']
    example = row['例句']
    result = generate_dialogue(word, definition, example)
    results.append(result)

    # Save to a JSON file
    output_file = 'generated_dialogues.json'
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

print(f"JSON output saved to {output_file}")
