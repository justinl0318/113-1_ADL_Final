from cosyvoice.cli.cosyvoice import CosyVoice
from cosyvoice.utils.file_utils import load_wav
import torchaudio
import json

# read text
with open("text.json", 'r') as f:
    text = json.load(f)
# print(text)

# load TTS
# zero_shot usage, <|zh|><|en|><|jp|><|yue|><|ko|> for Chinese/English/Japanese/Cantonese/Korean
cosyvoice = CosyVoice('pretrained_models/CosyVoice-300M') # or change to pretrained_models/CosyVoice-300M for 50Hz inference
prompt_speech_16k = load_wav('zero_shot_prompt.wav', 16000)

# FUNC
def gen_audio(text, path):
    for i, j in enumerate(cosyvoice.inference_zero_shot(text, '希望你以后能够做的比我还好呦。', prompt_speech_16k, stream=False)):
        torchaudio.save(f'audio_files/{path}.wav', j['tts_speech'], 22050)

def convert_digits_to_chinese(input_str):
    chinese_digits = ["零", "一", "二", "三", "四", "五", "六", "七", "八", "九"]
    
    # 將字串中的數字轉成中文數字
    result_str = "".join(chinese_digits[int(char)] if char.isdigit() else char for char in input_str)
    return result_str

# generate audios
audio = []
idx = 0
for data in text:
    audio_paths = []

    gen_audio(convert_digits_to_chinese(data["word"]), str(idx))
    word_audio_file_name = str(idx)
    idx += 1
    for dialogue in data["dialogues"]:
        gen_audio(convert_digits_to_chinese(dialogue["A"]), str(idx))
        gen_audio(convert_digits_to_chinese(dialogue["B"]), str(idx + 1))
        audio_paths.append(
            {
                "A": f'audio_files/{str(idx)}.wav',
                "B": f'audio_files/{str(idx + 1)}.wav'
            }
        )
        idx += 2
    audio.append(
        {
            "word": data["word"],
            "word_audio_path": f'audio_files/{word_audio_file_name}.wav',
            "paths": audio_paths
        }
    )

# save path of audio
with open(f"audio.json", 'w', encoding="utf-8") as f:
    json.dump(audio, f, ensure_ascii=False, indent=2)