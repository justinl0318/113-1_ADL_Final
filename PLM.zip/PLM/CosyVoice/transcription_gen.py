from faster_whisper import WhisperModel
import soundfile as sf
import json
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

# read audio
with open("audio.json", 'r') as f:
    audio = json.load(f)
# print(audio)

# load ASR
model_id = "/home/nlp/b10902031/aivt/models/models--andybi7676--cool-whisper/snapshots/9243ae0ca0cff575d2ca8a5c5698e232bf47821c"
model = WhisperModel(model_id, device='cuda', compute_type="float16")

# FUNC
def gen_segements(audio_fpath):
    concat_segements = []
    segments, info = model.transcribe(
        word_timestamps=True, 
        audio=audio_fpath, 
        # beam_size=5, 
        # language="zh", 
        # condition_on_previous_text=True
    ) # zh for zh-en code-switching in cool-whisper
    # for segment in segments:
    #     for word in segment.words:
    #         print(word)
    #         concat_segements.append(
    #             # {
    #             #     "start": round(segment.start, 2),
    #             #     "end": round(segment.end, 2),
    #             #     "word": segment.text
    #             # }
    #             {
    #                 "start": word.start,
    #                 "end": word.end,
    #                 "word": word.word
    #             }
    #         )
    #     # print("[%.2fs -> %.2fs] %s" % (segment.start, segment.end, segment.text))
    return segments

# generate transcriptions
transcription = []
for data in audio:
    concated_segments = []
    sentences = []

    for audio_path in data["paths"]:
        # audio_fpath = "voice.wav"
        # audio_info = sf.info(audio_fpath)
        # print(audio_info) # for debug
        concated_segment_A = []
        sentence_A = ""
        segment_A = gen_segements(audio_path["A"])
        for seg in segment_A:
            for word in seg.words:
                concated_segment_A.append(
                    {
                        "start": word.start,
                        "end": word.end,
                        "word": word.word
                    }
                )
                sentence_A += word.word

        concated_segment_B = []
        sentence_B = ""
        segment_B = gen_segements(audio_path["B"])
        for seg in segment_B:
            for word in seg.words:
                concated_segment_B.append(
                    {
                        "start": word.start,
                        "end": word.end,
                        "word": word.word
                    }
                )
                sentence_B += word.word

        concated_segments.append(
            {
                "A": concated_segment_A,
                "B": concated_segment_B
            }
        )
        sentences.append(
            {
                "A": sentence_A,
                "B": sentence_B
            }
        )
    
    transcription.append(
        {
            "word": data["word"],
            "word_level_transcriptions": concated_segments,
            "sentences": sentences
        }
    )

# save transcriptions
with open(f"transcription.json", 'w', encoding="utf-8") as f:
    json.dump(transcription, f, ensure_ascii=False, indent=2)
        